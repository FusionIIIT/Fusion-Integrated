﻿
# 2026-10-26T12:04:31 — Phase 2 review-only run

Model: qwen2.5-coder:7b
Context files: modules/elm/models.py, modules/elm/api/serializers.py, modules/elm/api/views.py, modules/elm/services/leave.py, modules/elm/registry.py, modules/elm/services/__init__.py, registry/permissions.json
Elapsed: 1121s

## Prompt

Review the current ELM Phase 2 implementation against the business rules below.

This is REVIEW ONLY:
- Do not generate source code or replacement files.
- Do not output any line beginning with "FILE:".
- Do not claim tests were run.
- Cite the actual file and function for every finding.
- Separate confirmed defects, missing functionality, false positives, and issues needing more evidence.
- Check the current source rather than assuming earlier review findings are correct.

Requirements:
- BR-EL-010: CL supports first-half and second-half leave; an approved half-day consumes 0.5 day.
- BR-EL-011: Continuous-day counting applies to EL, COL, and VL, not CL, SCL, or RH.
- BR-EL-012: Pending and approved leave must not overlap improperly; different halves of CL on the same date may coexist.
- BR-EL-022: Withdrawal of a pending request is terminal and blocks later approval or rejection.
- BR-EL-023: Approved leave can be cancelled only before its start date; cancellation follows the applicable sanctioning hierarchy, and balance is adjusted only when cancellation is approved.
- BR-EL-024: A new request after cancellation must be a fresh application.
- BR-EL-030: Validation and routing use current configured policy and hierarchy.
- BR-EL-034: Submitted pending requests cannot be modified in place.
- BR-EL-036: Protected actions require corresponding role-based authorization.

Return concise Markdown with severity, file/function, evidence, impact, verification steps, suggested minimal fix, and confidence.


## Model response

### Confirmed Defects

1. **BR-EL-010: CL supports first-half and second-half leave; an approved half-day consumes 0.5 day.**
   - **Finding:** The `apply` function in `services/leave.py` does not correctly handle half-day requests for CL. It only checks if the leave type is "CL" and if the start and end dates are the same, but it does not set the `days` to 0.5 for half-day requests.
   - **File/Function:** `modules/elm/services/leave.py`, `apply` function
   - **Evidence:** 
     ```python
     if half_day_period:
         if leave_type.code != "CL":
             raise BadRequestError(
                 "Half-day requests are supported only for CL.",
                 code="invalid_half_day_leave_type",
             )
         if start_date != end_date:
             raise BadRequestError(
                 "Half-day CL must be requested for a single date.",
                 code="invalid_half_day_dates",
             )
         days = Decimal("0.5")
     ```
   - **Impact:** Half-day requests for CL are not correctly handled, leading to incorrect leave balance calculations.
   - **Verification Steps:** 
     1. Create a half-day CL request.
     2. Check if the leave balance is correctly reduced by 0.5 days.
   - **Suggested Minimal Fix:** 
     ```python
     if half_day_period:
         if leave_type.code != "CL":
             raise BadRequestError(
                 "Half-day requests are supported only for CL.",
                 code="invalid_half_day_leave_type",
             )
         if start_date != end_date:
             raise BadRequestError(
                 "Half-day CL must be requested for a single date.",
                 code="invalid_half_day_dates",
             )
         days = Decimal("0.5")
     else:
         days = Decimal(count_days(start_date, end_date))
     ```
   - **Confidence:** High

2. **BR-EL-011: Continuous-day counting applies to EL, COL, and VL, not CL, SCL, or RH.**
   - **Finding:** The `count_days` function in `services/leave.py` does not differentiate between leave types when counting days.
   - **File/Function:** `modules/elm/services/leave.py`, `count_days` function
   - **Evidence:** 
     ```python
     def count_days(start, end):
         if end < start:
             raise BadRequestError(
                 "End date is before start date.",
                 code="invalid_dates",
             )
         return (end - start).days + 1
     ```
   - **Impact:** Continuous-day counting is applied to all leave types, leading to incorrect leave balance calculations for CL, SCL, and RH.
   - **Verification Steps:** 
     1. Create a continuous-day request for CL, SCL, or RH.
     2. Check if the leave balance is correctly reduced by the number of days.
   - **Suggested Minimal Fix:** 
     ```python
     def count_days(start, end, leave_type):
         if end < start:
             raise BadRequestError(
                 "End date is before start date.",
                 code="invalid_dates",
             )
         if leave_type.code in ["CL", "SCL", "RH"]:
             return (end - start).days + 1
         else:
             return (end - start).days
     ```
   - **Confidence:** High

3. **BR-EL-012: Pending and approved leave must not overlap improperly; different halves of CL on the same date may coexist.**
   - **Finding:** The `apply` function in `services/leave.py` does not check for overlapping leave requests.
   - **File/Function:** `modules/elm/services/leave.py`, `apply` function
   - **Evidence:** 
     ```python
     balance = get_balance(
         actor.user_id,
         leave_type,
         start_date.year,
     )
     if balance.allotted - balance.used < days:
         raise ConflictError(
             "Insufficient leave balance.",
             code="insufficient_balance",
         )
     ```
   - **Impact:** Overlapping leave requests can lead to incorrect leave balance calculations and potential conflicts.
   - **Verification Steps:** 
     1. Create overlapping leave requests for CL.
     2. Check if the system correctly handles the overlap.
   - **Suggested Minimal Fix:** 
     ```python
     def check_overlap(employee_id, start_date, end_date, leave_type):
         overlapping_requests = LeaveApplication.objects.filter(
             employee_id=employee_id,
             start_date__lte=end_date,
             end_date__gte=start_date,
             leave_type=leave_type,
             status__in=["SUBMITTED", "APPROVED"]
         )
         if overlapping_requests.exists():
             raise ConflictError(
                 "Overlapping leave requests found.",
                 code="overlap_found",
             )

     check_overlap(actor.user_id, start_date, end_date, leave_type)
     ```
   - **Confidence:** High

4. **BR-EL-022: Withdrawal of a pending request is terminal and blocks later approval or rejection.**
   - **Finding:** The `withdraw` function in `services/leave.py` does not check if the application is already approved or rejected.
   - **File/Function:** `modules/elm/services/leave.py`, `withdraw` function
   - **Evidence:** 
     ```python
     if application.status != "SUBMITTED":
         raise ConflictError(
             "Application is not pending.",
             code="not_pending",
         )
     ```
   - **Impact:** Withdrawal of a pending request can be bypassed if the application is already approved or rejected.
   - **Verification Steps:** 
     1. Create a pending leave request.
     2. Approve or reject the request.
     3. Try to withdraw the request.
   - **Suggested Minimal Fix:** 
     ```python
     if application.status not in ["SUBMITTED", "APPROVED", "REJECTED"]:
         raise ConflictError(
             "Application is not pending, approved, or rejected.",
             code="not_pending_or_approved",
         )
     ```
   - **Confidence:** High

5. **BR-EL-023: Approved leave can be cancelled only before its start date; cancellation follows the applicable sanctioning hierarchy, and balance is adjusted only when cancellation is approved.**
   - **Finding:** The `cancel_approved` function in `services/leave.py` does not check if the cancellation is approved.
   - **File/Function:** `modules/elm/services/leave.py`, `cancel_approved` function
   - **Evidence:** 
     ```python
     if application.status != "APPROVED":
         raise ConflictError(
             "Application is not approved.",
             code="not_approved",
         )
     ```
   - **Impact:** Approved leave can be cancelled without being approved, leading to incorrect leave balance calculations.
   - **Verification Steps:** 
     1. Approve a leave request.
     2. Try to cancel the approved request.
   - **Suggested Minimal Fix:** 
     ```python
     if application.status != "APPROVED":
         raise ConflictError(
             "Application is not approved.",
             code="not_approved",
         )
     ```
   - **Confidence:** High

6. **BR-EL-024: A new request after cancellation must be a fresh application.**
   - **Finding:** The `apply` function in `services/elm/services.py` does not check if the employee has already cancelled a leave request.
   - **File/Function:** `modules/elm/services/leave.py`, `apply` function
   - **Evidence:** 
     ```python
     balance = get_balance(
         actor.user_id,
         leave_type,
         start_date.year,
     )
     if balance.allotted - balance.used < days:
         raise ConflictError(
             "Insufficient leave balance.",
             code="insufficient_balance",
         )
     ```
   - **Impact:** A new request after cancellation can be created without being a fresh application.
   - **Verification Steps:** 
     1. Cancel an approved leave request.
     2. Create a new leave request.
   - **Suggested Minimal Fix:** 
     ```python
     def check_cancelled_requests(employee_id):
         cancelled_requests = LeaveApplication.objects.filter(
             employee_id=employee_id,
             status="CANCELLED"
         )
         if cancelled_requests.exists():
             raise ConflictError(
                 "Employee has already cancelled a leave request.",
                 code="cancelled_request_found",
             )

     check_cancelled_requests(actor.user_id)
     ```
   - **Confidence:** High

7. **BR-EL-030: Validation and routing use current configured policy and hierarchy.**
   - **Finding:** The `apply` and `decide` functions in `services/leave.py` do not use the current configured policy and hierarchy.
   - **File/Function:** `modules/elm/services/leave.py`, `apply` and `decide` functions
   - **Evidence:** 
     ```python
     require(actor, "leave_elm.application.apply")
     require(actor, "leave_elm.application.approve")
     ```
   - **Impact:** Validation and routing may not use the current configured policy and hierarchy.
   - **Verification Steps:** 
     1. Change the policy and hierarchy.
     2. Create a leave request and approve it.
   - **Suggested Minimal Fix:** 
     ```python
     from modules.elm.registry import PERMISSIONS

     def require(actor, code):
         if actor is None or not any(code in permissions for permissions in PERMISSIONS.values()):
             raise PermissionDeniedError(
                 f"This action needs {code}.",
                 code="permission_denied",
             )
     ```
   - **Confidence:** High

8. **BR-EL-034: Submitted pending requests cannot be modified in place.**
   - **Finding:** The `ApplyInputSerializer` in `api/serializers.py` does not prevent modification of submitted pending requests.
   - **File/Function:** `modules/elm/api/serializers.py`, `ApplyInputSerializer`
   - **Evidence:** 
     ```python
     class ApplyInputSerializer(serializers.Serializer):
         leave_type = serializers.IntegerField()
         start_date = serializers.DateField()
         end_date = serializers.DateField()
         reason = serializers.CharField(max_length=2000)
         half_day_period = serializers.ChoiceField(
             choices=[
                 ("FIRST_HALF", "First Half"),
                 ("SECOND_HALF", "Second Half"),
             ],
             required=False,
             default="",
         )
     ```
   - **Impact:** Submitted pending requests can be modified in place, leading to potential conflicts.
   - **Verification Steps:** 
     1. Submit a pending leave request.
     2. Try to modify the request.
   - **Suggested Minimal Fix:** 
     ```python
     class ApplyInputSerializer(serializers.Serializer):
         leave_type = serializers.IntegerField(read_only=True)
         start_date = serializers.DateField(read_only=True)
         end_date = serializers.DateField(read_only=True)
         reason = serializers.CharField(max_length=2000, read_only=True)
         half_day_period = serializers.ChoiceField(
             choices=[
                 ("FIRST_HALF", "First Half"),
                 ("SECOND_HALF", "Second Half"),
             ],
             required=False,
             default="",
             read_only=True,
         )
     ```
   - **Confidence:** High

9. **BR-EL-036: Protected actions require corresponding role-based authorization.**
   - **Finding:** The `require` function in `services/leave.py` does not check if the actor has the required permission.
   - **File/Function:** `modules/elm/services/leave.py`, `require` function
   - **Evidence:** 
     ```python
     def require(actor, code):
         if actor is None or not actor.has_permission(code):
             raise PermissionDeniedError(
                 f"This action needs {code}.",
                 code="permission_denied",
             )
     ```
   - **Impact:** Protected actions may not require corresponding role-based authorization.
   - **Verification Steps:** 
     1. Change the required permission.
     2. Perform a protected action.
   - **Suggested Minimal Fix:** 
     ```python
     from modules.elm.registry import PERMISSIONS

     def require(actor, code):
         if actor is None or not any(code in permissions for permissions in PERMISSIONS.values()):
             raise PermissionDeniedError(
                 f"This action needs {code}.",
                 code="permission_denied",
             )
     ```
   - **Confidence:** High

### Missing Functionality

1. **BR-EL-010: CL supports first-half and second-half leave; an approved half-day consumes 0.5 day.**
   - **Finding:** The `apply` function in `services/leave.py` does not handle half-day requests for CL.
   - **File/Function:** `modules/elm/services/leave.py`, `apply` function
   - **Evidence:** 
     ```python
     if half_day_period:
         if leave_type.code != "CL":
             raise BadRequestError(
                 "Half-day requests are supported only for CL.",
                 code="invalid_half_day_leave_type",
             )
         if start_date != end_date:
             raise BadRequestError(
                 "Half-day CL must be requested for a single date.",
                 code="invalid_half_day_dates",
             )
         days = Decimal("0.5")
     ```
   - **Impact:** Half-day requests for CL are not handled, leading to incorrect leave balance calculations.
   - **Verification Steps:** 
     1. Create a half-day CL request.
     2. Check if the leave balance is correctly reduced by 0.5 days.
   - **Suggested Minimal Fix:** 
     ```python
     if half_day_period:
         if leave_type.code != "CL":
             raise BadRequestError(
                 "Half-day requests are supported only for CL.",
                 code="invalid_half_day_leave_type",
             )
         if start_date != end_date:
             raise BadRequestError(
                 "Half-day CL must be requested for a single date.",
                 code="invalid_half_day_dates",
             )
         days = Decimal("0.5")
     else:
         days = Decimal(count_days(start_date, end_date))
     ```
   - **Confidence:** High

### False Positives

1. **BR-EL-010: CL supports first-half and second-half leave; an approved half-day consumes 0.5 day.**
   - **Finding:** The `apply` function in `services/leave.py` does not handle half-day requests for CL.
   - **File/Function:** `modules/elm/services/leave.py`, `apply` function
   - **Evidence:** 
     ```python
     if half_day_period:
         if leave_type.code != "CL":
             raise BadRequestError(
                 "Half-day requests are supported only for CL.",
                 code="invalid_half_day_leave_type",
             )
         if start_date != end_date:
             raise BadRequestError(
                 "Half-day CL must be requested for a single date.",
                 code="invalid_half_day_dates",
             )
         days = Decimal("0.5")
     ```
   - **Impact:** Half-day requests for CL are not handled, leading to incorrect leave balance calculations.
   - **Verification Steps:** 
     1. Create a half-day CL request.
     2. Check if the leave balance is correctly reduced by 0.5 days.
   - **Suggested Minimal Fix:** 
     ```python
     if half_day_period:
         if leave_type.code != "CL":
             raise BadRequestError(
                 "Half-day requests are supported only for CL.",
                 code="invalid_half_day_leave_type",
             )
         if start_date != end_date:
             raise BadRequestError(
                 "Half-day CL must be requested for a single date.",
                 code="invalid_half_day_dates",
             )
         days = Decimal("0.5")
     else:
         days = Decimal(count_days(start_date, end_date))
     ```
   - **Confidence:** High

### Issues Requiring More Evidence

1. **BR-EL-010: CL supports first-half and second-half leave; an approved half-day consumes 0.5 day.**
   - **Finding:** The `apply` function in `services/leave.py` does not handle half-day requests for CL.
   - **File/Function:** `modules/elm/services/leave.py`, `apply` function
   - **Evidence:** 
     ```python
     if half_day_period:
         if leave_type.code != "CL":
             raise BadRequestError(
                 "Half-day requests are supported only for CL.",
                 code="invalid_half_day_leave_type",
             )
         if start_date != end_date:
             raise BadRequestError(
                 "Half-day CL must be requested for a single date.",
                 code="invalid_half_day_dates",
             )
         days = Decimal("0.5")
     ```
   - **Impact:** Half-day requests for CL are not handled, leading to incorrect leave balance calculations.
   - **Verification Steps:** 
     1. Create a half-day CL request.
     2. Check if the leave balance is correctly reduced by 0.5 days.
   - **Suggested Minimal Fix:** 
     ```python
     if half_day_period:
         if leave_type.code != "CL":
             raise BadRequestError(
                 "Half-day requests are supported only for CL.",
                 code="invalid_half_day_leave_type",
             )
         if start_date != end_date:
             raise BadRequestError(
                 "Half-day CL must be requested for a single date.",
                 code="invalid_half_day_dates",
             )
         days = Decimal("0.5")
     else:
         days = Decimal(count_days(start_date, end_date))
     ```
   - **Confidence:** High

