﻿You are helping improve the Fusion ERP ELM module for Phase 2.

Review the current source files and propose a minimal fix for this issue:
ApplyInputSerializer accepts half_day_period, and LeaveApplication has that field, but the API view appears not to pass half_day_period to services.apply().

Check the actual services.apply signature before proposing changes.
Ensure the API passes the validated field and the response serializer exposes it if appropriate.
Preserve unrelated behavior. Do not modify repository files.
Return the exact minimal changes and tests to run. Do not claim tests were run.
