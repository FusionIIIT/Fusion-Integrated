
param(
    [Parameter(Mandatory=$true)][string]$PromptFile,
    [string[]]$Context = @(),
    [string]$Target = "",
    [string]$Model = "qwen2.5-coder:7b",
    [int]$NumCtx = 12288,
    [string]$Repo = (Get-Location).Path,
    [string]$Log = ".\logs\model_chat.md"
)

$ErrorActionPreference = "Stop"

if (-not (Test-Path $PromptFile)) {
    throw "Prompt file not found: $PromptFile"
}
if (-not (Get-Command ollama -ErrorAction SilentlyContinue)) {
    throw "Ollama CLI not found."
}

$null = Invoke-RestMethod -Uri "http://127.0.0.1:11434/api/tags" -TimeoutSec 10

# Split comma-separated context paths into separate entries.
$Context = @(
    $Context |
        ForEach-Object { $_ -split ',' } |
        ForEach-Object { $_.Trim() } |
        Where-Object { $_ }
)

$task = Get-Content $PromptFile -Raw -Encoding UTF8
$ctx = ""

foreach ($c in $Context) {
    $full = Join-Path $Repo $c

    if (-not (Test-Path $full -PathType Leaf)) {
        Write-Warning "Skipping missing context file: $full"
        continue
    }

    Write-Host "Loading context: $c"
    $ctx += "`n--- FILE: $c ---`n"
    $ctx += (Get-Content $full -Raw -Encoding UTF8)
    $ctx += "`n"
}

if ([string]::IsNullOrWhiteSpace($ctx)) {
    throw "No context files loaded. Stopping to avoid context-free generation."
}

$system = @"
You are generating code for the Fusion ERP repository.
Output ONLY files you create or change.
For every file use exactly this format:

FILE: relative/path/from/repo/root
``````python
<entire file content>
``````

Use the correct language fence for each file.
Give complete files, not diffs.
Do not include explanations outside the files.
"@

$user = "Repository context files:`n$ctx`n`nTASK:`n$task"

$body = @{
    model = $Model
    stream = $false
    options = @{
        num_ctx = $NumCtx
        temperature = 0.2
    }
    messages = @(
        @{ role = "system"; content = $system },
        @{ role = "user"; content = $user }
    )
} | ConvertTo-Json -Depth 8

Write-Host "Model: $Model"
Write-Host "Context files supplied: $($Context.Count)"
Write-Host "Sending request to local Ollama. Please wait..."

$start = Get-Date

$response = Invoke-RestMethod `
    -Uri "http://127.0.0.1:11434/api/chat" `
    -Method Post `
    -Body ([Text.Encoding]::UTF8.GetBytes($body)) `
    -ContentType "application/json; charset=utf-8" `
    -TimeoutSec 3600

$seconds = [int]((Get-Date) - $start).TotalSeconds
$out = [string]$response.message.content

if ([string]::IsNullOrWhiteSpace($out)) {
    throw "Ollama returned an empty response."
}

$logDir = Split-Path -Parent $Log
if ($logDir) {
    New-Item -ItemType Directory -Force $logDir | Out-Null
}

$stats = "model=$Model num_ctx=$NumCtx prompt_tokens=$($response.prompt_eval_count) output_tokens=$($response.eval_count) wall=${seconds}s"

Add-Content $Log -Encoding utf8 @"

# $(Get-Date -Format s) ($stats)

Prompt file: $PromptFile
Context: $($Context -join ', ')

## Prompt

$task

## Model response

$out

"@

# Parse complete FILE: blocks from the model response.
$rx = [regex]'(?ms)^FILE:\s*([^\r\n]+?)\s*\r?\n```[a-zA-Z0-9_+-]*\r?\n(.*?)\r?\n```'
$count = 0

foreach ($m in $rx.Matches($out)) {
    $rel = $m.Groups[1].Value.Trim()

    if ([IO.Path]::IsPathRooted($rel) -or
        $rel.Split('/') -contains '..' -or
        $rel.Split('\') -contains '..') {
        Write-Warning "Skipping unsafe path: $rel"
        continue
    }

    $dest = Join-Path $Repo $rel
    New-Item -ItemType Directory -Force (Split-Path $dest) | Out-Null

    [IO.File]::WriteAllText(
        $dest,
        $m.Groups[2].Value + "`n",
        (New-Object System.Text.UTF8Encoding $false)
    )

    Write-Host "Wrote $rel"
    $count++
}

if ($count -eq 0 -and $Target) {
    $b = [regex]::Match(
        $out,
        '(?ms)```[a-zA-Z0-9_+-]*\r?\n(.*?)\r?\n```'
    )

    if ($b.Success) {
        $dest = Join-Path $Repo $Target
        New-Item -ItemType Directory -Force (Split-Path $dest) | Out-Null

        [IO.File]::WriteAllText(
            $dest,
            $b.Groups[1].Value + "`n",
            (New-Object System.Text.UTF8Encoding $false)
        )

        Write-Host "Wrote $Target (Target fallback)"
        $count = 1
    }
}

Write-Host $stats
Write-Host "Files written: $count"

if ($count -eq 0) {
    Write-Warning "No files parsed. Raw response saved in $Log"
    Write-Host $out
}
