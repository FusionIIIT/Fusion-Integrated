﻿
# 2026-10-11T23:34:15 (model=qwen2.5-coder:7b num_ctx=12288 prompt_tokens=416 output_tokens=551 wall=92s)

Prompt file: .\logs\prompts\01_backend_core.txt
Context: modules/directory/apps.py,modules/directory/registry.py,modules/directory/models.py,specs/01_ELM_Problem_Statement_v1.4_FINAL.md

## Prompt

Inspect the provided Fusion ERP base repository and ELM specification artifacts. Implement ELM as an integrated module, reusing Fusion authentication, roles, backend structure, and shared components.

Step 1 (backend core only). Follow modules/directory patterns:
- modules/elm/__init__.py empty.
- modules/elm/apps.py: ElmConfig, name "modules.elm", label "elm".
- modules/elm/registry.py: PERMISSIONS, SYSTEM_PERMISSIONS = [], ROLE_GRANTS. Every permission starts "leave_elm.". Permissions: leave_elm.application.view, leave_elm.application.apply, leave_elm.application.approve, leave_elm.balance.view, leave_elm.policy.manage. Roles: Employee (view, apply, balance.view), Leave Approver (view, approve, balance.view), Leave Admin (view, balance.view, policy.manage). Every permission granted to at least one role.
- modules/elm/models.py uses core.db.mixins.TimeStampedModel. Models: LeaveType (code, name, max_days_per_year, requires_document, is_active); LeaveBalance (employee_id IntegerField, leave_type FK, year, allotted, used); LeaveApplication (employee_id IntegerField, leave_type FK, start_date, end_date, days, reason, status choices DRAFT/SUBMITTED/APPROVED/REJECTED/CANCELLED, approver_id IntegerField null, remarks, decided_at null). Do not ForeignKey to User; store IAM user IDs as IntegerField like modules/directory. Every model db_table starts elm_.
Use the supplied problem statement and business rules as context. Output only generated files in FILE: format.


## Model response

FILE: modules/elm/__init__.py
```python
# Empty file
```

FILE: modules/elm/apps.py
```python
from django.apps import AppConfig

class ElmConfig(AppConfig):
    name = 'modules.elm'
    label = 'elm'
```

FILE: modules/elm/registry.py
```python
PERMISSIONS = [
    'leave_elm.application.view',
    'leave_elm.application.apply',
    'leave_elm.application.approve',
    'leave_elm.balance.view',
    'leave_elm.policy.manage',
]

SYSTEM_PERMISSIONS = []

ROLE_GRANTS = {
    'Employee': [
        'leave_elm.application.view',
        'leave_elm.application.apply',
        'leave_elm.balance.view',
    ],
    'Leave Approver': [
        'leave_elm.application.view',
        'leave_elm.application.approve',
        'leave_elm.balance.view',
    ],
    'Leave Admin': [
        'leave_elm.application.view',
        'leave_elm.balance.view',
        'leave_elm.policy.manage',
    ],
}
```

FILE: modules/elm/models.py
```python
from django.db import models
from core.db.mixins import TimeStampedModel

class LeaveType(TimeStampedModel):
    code = models.CharField(max_length=10, unique=True)
    name = models.CharField(max_length=100)
    max_days_per_year = models.IntegerField()
    requires_document = models.BooleanField(default=False)
    is_active = models.BooleanField(default=True)
    db_table = 'elm_leave_type'

class LeaveBalance(TimeStampedModel):
    employee_id = models.IntegerField()
    leave_type = models.ForeignKey('LeaveType', on_delete=models.CASCADE, db_column='leave_type_id')
    year = models.IntegerField()
    allotted = models.IntegerField()
    used = models.IntegerField()
    db_table = 'elm_leave_balance'

class LeaveApplication(TimeStampedModel):
    employee_id = models.IntegerField()
    leave_type = models.ForeignKey('LeaveType', on_delete=models.CASCADE, db_column='leave_type_id')
    start_date = models.DateField()
    end_date = models.DateField()
    days = models.IntegerField()
    reason = models.TextField()
    status = models.CharField(max_length=20, choices=[
        ('DRAFT', 'Draft'),
        ('SUBMITTED', 'Submitted'),
        ('APPROVED', 'Approved'),
        ('REJECTED', 'Rejected'),
        ('CANCELLED', 'Cancelled'),
    ])
    approver_id = models.IntegerField(null=True, blank=True)
    remarks = models.TextField(null=True, blank=True)
    decided_at = models.DateTimeField(null=True, blank=True)
    db_table = 'elm_leave_application'
```


# 2026-10-11T23:44:20 (model=qwen2.5-coder:7b num_ctx=12288 prompt_tokens=3835 output_tokens=635 wall=168s)

Prompt file: .\logs\prompts\01_backend_core.txt
Context: modules/directory/apps.py, modules/directory/registry.py, modules/directory/models.py, specs/01_ELM_Problem_Statement_v1.4_FINAL.md

## Prompt

Inspect the provided Fusion ERP base repository and ELM specification artifacts. Implement ELM as an integrated module, reusing Fusion authentication, roles, backend structure, and shared components.

Step 1 (backend core only). Follow modules/directory patterns:
- modules/elm/__init__.py empty.
- modules/elm/apps.py: ElmConfig, name "modules.elm", label "elm".
- modules/elm/registry.py: PERMISSIONS, SYSTEM_PERMISSIONS = [], ROLE_GRANTS. Every permission starts "leave_elm.". Permissions: leave_elm.application.view, leave_elm.application.apply, leave_elm.application.approve, leave_elm.balance.view, leave_elm.policy.manage. Roles: Employee (view, apply, balance.view), Leave Approver (view, approve, balance.view), Leave Admin (view, balance.view, policy.manage). Every permission granted to at least one role.
- modules/elm/models.py uses core.db.mixins.TimeStampedModel. Models: LeaveType (code, name, max_days_per_year, requires_document, is_active); LeaveBalance (employee_id IntegerField, leave_type FK, year, allotted, used); LeaveApplication (employee_id IntegerField, leave_type FK, start_date, end_date, days, reason, status choices DRAFT/SUBMITTED/APPROVED/REJECTED/CANCELLED, approver_id IntegerField null, remarks, decided_at null). Do not ForeignKey to User; store IAM user IDs as IntegerField like modules/directory. Every model db_table starts elm_.
Use the supplied problem statement and business rules as context. Output only generated files in FILE: format.


## Model response

FILE: modules/elm/__init__.py
```python
# Empty file
```

FILE: modules/elm/apps.py
```python
from django.apps import AppConfig


class ElmConfig(AppConfig):
    name = "modules.elm"
    label = "elm"
```

FILE: modules/elm/registry.py
```python
PERMISSIONS = [
    ("leave_elm.application.view", "View leave applications"),
    ("leave_elm.application.apply", "Apply for leave"),
    ("leave_elm.application.approve", "Approve leave applications"),
    ("leave_elm.balance.view", "View leave balances"),
    ("leave_elm.policy.manage", "Manage leave policies"),
]

SYSTEM_PERMISSIONS = []

_EMPLOYEE = ["leave_elm.application.view", "leave_elm.balance.view"]
_LEAVE_APPROVER = ["leave_elm.application.view", "leave_elm.application.approve", "leave_elm.balance.view"]
_LEAVE_ADMIN = ["leave_elm.application.view", "leave_elm.balance.view", "leave_elm.policy.manage"]

#: Keyed by the role name as it exists in globals_designation.
ROLE_GRANTS = {
    "Employee": _EMPLOYEE,
    "Leave Approver": _LEAVE_APPROVER,
    "Leave Admin": _LEAVE_ADMIN,
}
```

FILE: modules/elm/models.py
```python
from django.db import models

from core.db.mixins import TimeStampedModel


class LeaveType(TimeStampedModel):
    code = models.CharField(max_length=16, unique=True)
    name = models.CharField(max_length=64)
    max_days_per_year = models.PositiveSmallIntegerField()
    requires_document = models.BooleanField(default=False)
    is_active = models.BooleanField(default=True)

    class Meta:
        db_table = "elm_leave_type"


class LeaveBalance(TimeStampedModel):
    employee_id = models.IntegerField()
    leave_type = models.ForeignKey("LeaveType", on_delete=models.CASCADE)
    year = models.PositiveSmallIntegerField()
    allotted = models.DecimalField(max_digits=10, decimal_places=2)
    used = models.DecimalField(max_digits=10, decimal_places=2)

    class Meta:
        db_table = "elm_leave_balance"
        unique_together = ("employee_id", "leave_type", "year")


class LeaveApplication(TimeStampedModel):
    employee_id = models.IntegerField()
    leave_type = models.ForeignKey("LeaveType", on_delete=models.CASCADE)
    start_date = models.DateField()
    end_date = models.DateField()
    days = models.DecimalField(max_digits=10, decimal_places=2)
    reason = models.TextField()
    status = models.CharField(max_length=16, choices=[("DRAFT", "Draft"), ("SUBMITTED", "Submitted"), ("APPROVED", "Approved"), ("REJECTED", "Rejected"), ("CANCELLED", "Cancelled")], default="DRAFT")
    approver_id = models.IntegerField(null=True, blank=True)
    remarks = models.TextField(blank=True)
    decided_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        db_table = "elm_leave_application"
```


# 2026-10-11T23:48:46 (model=qwen2.5-coder:7b num_ctx=12288 prompt_tokens=2235 output_tokens=873 wall=179s)

Prompt file: .\logs\prompts\02a_registry_urls.txt
Context: modules/elm/registry.py, modules/placement/registry.py, config/urls.py

## Prompt

Step 2a (wiring). Update two files.
1. modules/elm/registry.py: keep PERMISSIONS, SYSTEM_PERMISSIONS and ROLE_GRANTS exactly as generated. Change module docstring to describe ELM. Add MODULE and NAV_ITEMS in the same shape as modules/placement/registry.py:
MODULE = {"code":"leave_elm","label":"Leave Management","icon":"CalendarBlank","base_path":"/leave","nav_section":"Leave","sort_order":20,"status":"active"}
NAV_ITEMS keys: code, label, icon, to, required_permission, sort_order:
- leave.apply / Apply for Leave / PencilSimple / /leave/apply / leave_elm.application.apply / 10
- leave.mine / My Applications / ListChecks / /leave/mine / leave_elm.application.view / 20
- leave.balance / Leave Balance / Scales / /leave/balance / leave_elm.balance.view / 30
- leave.approvals / Approvals / UserCheck / /leave/approvals / leave_elm.application.approve / 50
- leave.types / Leave Types / Gear / /leave/types / leave_elm.policy.manage / 60
2. config/urls.py: preserve existing lines and add path("api/v1/elm/", include("modules.elm.api.urls")) after placement line.
Output complete changed files only.


## Model response

FILE: modules/elm/registry.py
```python
"""What the server tells the shell about this module (ADR-0010).

Nav items carry `required_permission` and the server filters before sending —
the client does zero filtering, so a link a role cannot use never reaches the
browser at all.
"""
MODULE = {
    "code": "leave_elm", "label": "Leave Management", "icon": "CalendarBlank",
    "base_path": "/leave", "nav_section": "Leave", "sort_order": 20,
    "status": "active",
}

NAV_ITEMS = [
    {"code": "leave.apply", "label": "Apply for Leave", "icon": "PencilSimple", "to": "/leave/apply", "required_permission": "leave_elm.application.apply", "sort_order": 10},
    {"code": "leave.mine", "label": "My Applications", "icon": "ListChecks", "to": "/leave/mine", "required_permission": "leave_elm.application.view", "sort_order": 20},
    {"code": "leave.balance", "label": "Leave Balance", "icon": "Scales", "to": "/leave/balance", "required_permission": "leave_elm.balance.view", "sort_order": 30},
    {"code": "leave.approvals", "label": "Approvals", "icon": "UserCheck", "to": "/leave/approvals", "required_permission": "leave_elm.application.approve", "sort_order": 50},
    {"code": "leave.types", "label": "Leave Types", "icon": "Gear", "to": "/leave/types", "required_permission": "leave_elm.policy.manage", "sort_order": 60},
]

#: Every permission this module recognises; ROLE_GRANTS below says who holds each.
PERMISSIONS = [
    ("leave_elm.application.view", "View leave applications"),
    ("leave_elm.application.apply", "Apply for leave"),
    ("leave_elm.application.approve", "Approve leave applications"),
    ("leave_elm.balance.view", "View leave balances"),
    ("leave_elm.policy.manage", "Manage leave policies"),
]

#: Performed by a service or a scheduled task, so no designation holds them.
SYSTEM_PERMISSIONS = []

_EMPLOYEE = ["leave_elm.application.view", "leave_elm.balance.view"]
_LEAVE_APPROVER = ["leave_elm.application.view", "leave_elm.application.approve", "leave_elm.balance.view"]
_LEAVE_ADMIN = ["leave_elm.application.view", "leave_elm.balance.view", "leave_elm.policy.manage"]

#: Keyed by the role name as it exists in globals_designation.
ROLE_GRANTS = {
    "Employee": _EMPLOYEE,
    "Leave Approver": _LEAVE_APPROVER,
    "Leave Admin": _LEAVE_ADMIN,
}
```

FILE: config/urls.py
```python
"""Root URLs.

Every module mounts itself under /api/v1/<module>/. A module that is not in
INSTALLED_APPS contributes no URLs at all — that is what "independent" means
here: removing a module is deleting a directory and one settings line.
"""
from django.urls import include, path
from drf_spectacular.views import SpectacularAPIView, SpectacularSwaggerView

import core.api.schema  # noqa: F401  registers the auth schemes by import
from core.api.health import healthz, readyz

urlpatterns = [
    path("healthz", healthz, name="healthz"),
    path("readyz", readyz, name="readyz"),
    path("api/v1/", include("fusion_auth.urls")),
    path("api/v1/directory/", include("modules.directory.api.urls")),
    path("api/v1/placement/", include("modules.placement.api.urls")),
    path("api/v1/elm/", include("modules.elm.api.urls")),  # Added line
    path("api/schema/", SpectacularAPIView.as_view(), name="schema"),
    path("api/docs/", SpectacularSwaggerView.as_view(url_name="schema"), name="docs"),
]
```


# 2026-10-11T23:56:00 (model=qwen2.5-coder:7b num_ctx=12288 prompt_tokens=10040 output_tokens=851 wall=400s)

Prompt file: .\logs\prompts\04_services.txt
Context: modules/elm/models.py, specs/04_ELM_Business_Rule_Specifications_v1.4_FINAL.md

## Prompt

Create modules/elm/services/__init__.py (empty) and modules/elm/services/leave.py implementing ELM services using modules/elm/models.py and supplied business-rule excerpt. Follow style of modules/placement/services/authz.py but do not import from modules.placement. Imports: datetime, django.db.transaction, django.utils.timezone, core.api.exceptions (BadRequestError, ConflictError, NotFoundError, PermissionDeniedError), and ELM models. actor is Principal with actor.user_id and actor.has_permission(code).
- require(actor, code): raise PermissionDeniedError("This action needs <code>.", code="permission_denied") if actor None or lacks permission.
- ACTIVE=("SUBMITTED","APPROVED")
- count_days(start,end): inclusive (end-start).days+1; if end<start raise BadRequestError("End date is before date.", code="invalid_dates").
- get_balance(employee_id, leave_type, year): return LeaveBalance or raise NotFoundError("No leave balance for this leave type.", code="no_balance").
- apply(actor, leave_type_id, start_date, end_date, reason): require leave_elm.application.apply; leave type exists and active; days=count_days; prevent overlapping ACTIVE applications for same employee (ConflictError code="overlap"); ensure allotted-used >= days else ConflictError code="insufficient_balance"; create SUBMITTED application inside transaction.atomic().
- decide(actor, application_id, approve: bool, remarks=""): require leave_elm.application.approve; transaction.atomic and select_for_update application; must be SUBMITTED else ConflictError code="not_pending"; cannot approve own application (PermissionDeniedError code="self_approval"); on approval lock balance and add days to used, status APPROVED; on rejection status REJECTED; set approver_id, remarks, decided_at=timezone.now(); return application.
- withdraw(actor, application_id): BR-EL-022; applicant only; status SUBMITTED; set CANCELLED.
- cancel_approved(actor, application_id): BR-EL-023; applicant only; status APPROVED and start_date after today; refund days to balance (used -= days) and status CANCELLED, atomic and select_for_update.
- BR-EL-034: no function edits submitted applications.
Each function one-line docstring naming its BR-EL ID. Output complete files only.


## Model response

FILE: modules/elm/services/__init__.py
```python
# Empty file
```

FILE: modules/elm/services/leave.py
```python
from datetime import datetime
from django.db import transaction
from django.utils import timezone
from core.api.exceptions import BadRequestError, ConflictError, NotFoundError, PermissionDeniedError
from modules.elm.models import LeaveType, LeaveBalance, LeaveApplication
from modules.elm import application as leave_elm_application


def require(actor, code):
    if actor is None or not actor.has_permission(code):
        raise PermissionDeniedError(f"This action needs {code}.", code="permission_denied")


def count_days(start, end):
    if end < start:
        raise BadRequestError("End date is before start date.", code="invalid_dates")
    return (end - start).days + 1


def get_balance(employee_id, leave_type, year):
    try:
        return LeaveBalance.objects.get(employee_id=employee_id, leave_type=leave_type, year=year)
    except LeaveBalance.DoesNotExist:
        raise NotFoundError("No leave balance for this leave type.", code="no_balance")


@transaction.atomic
def apply(actor, leave_type_id, start_date, end_date, reason):
    require(actor, "leave_elm.application.apply")
    leave_type = LeaveType.objects.get(id=leave_type_id)
    if not leave_type.is_active:
        raise BadRequestError("Leave type is not active.", code="inactive_leave_type")
    days = count_days(start_date, end_date)
    balance = get_balance(actor.user_id, leave_type, start_date.year)
    if balance.allotted - balance.used < days:
        raise ConflictError("Insufficient leave balance.", code="insufficient_balance")
    application = LeaveApplication.objects.create(
        employee_id=actor.user_id,
        leave_type=leave_type,
        start_date=start_date,
        end_date=end_date,
        days=days,
        reason=reason,
        status="SUBMITTED"
    )
    return application


@transaction.atomic
def decide(actor, application_id, approve: bool, remarks=""):
    require(actor, "leave_elm.application.approve")
    application = LeaveApplication.objects.select_for_update().get(id=application_id)
    if application.status not in ("SUBMITTED",):
        raise ConflictError("Application is not pending.", code="not_pending")
    if application.employee_id == actor.user_id:
        raise PermissionDeniedError("Cannot approve own application.", code="self_approval")
    if approve:
        balance = get_balance(application.employee_id, application.leave_type, application.start_date.year)
        with transaction.atomic():
            balance.used += application.days
            balance.save()
        application.status = "APPROVED"
    else:
        application.status = "REJECTED"
    application.approver_id = actor.user_id
    application.remarks = remarks
    application.decided_at = timezone.now()
    application.save()
    return application


@transaction.atomic
def withdraw(actor, application_id):
    require(actor, "leave_elm.application.withdraw")
    application = LeaveApplication.objects.select_for_update().get(id=application_id)
    if application.status != "SUBMITTED":
        raise ConflictError("Application is not pending.", code="not_pending")
    if application.employee_id != actor.user_id:
        raise PermissionDeniedError("Cannot withdraw other's application.", code="permission_denied")
    application.status = "CANCELLED"
    application.save()


@transaction.atomic
def cancel_approved(actor, application_id):
    require(actor, "leave_elm.application.cancel_approved")
    application = LeaveApplication.objects.select_for_update().get(id=application_id)
    if application.status != "APPROVED":
        raise ConflictError("Application is not approved.", code="not_approved")
    if application.start_date < timezone.now().date():
        raise ConflictError("Cannot cancel approved leave before start date.", code="invalid_date")
    balance = get_balance(application.employee_id, application.leave_type, application.start_date.year)
    with transaction.atomic():
        balance.used -= application.days
        balance.save()
    application.status = "CANCELLED"
    application.save()
```


# 2026-10-12T00:06:19 (model=qwen2.5-coder:7b num_ctx=12288 prompt_tokens=2609 output_tokens=2473 wall=567s)

Prompt file: .\logs\prompts\03_settings.txt
Context: config/settings/base.py

## Prompt

Update config/settings/base.py. Keep every existing line exactly as given, in the same order. The only change: in DOMAIN_MODULES list add "modules.elm", on a new line after "modules.placement". Output the complete file.


## Model response

```python
FILE: config/settings/base.py
```python
"""Fusion-Integrated — base settings.

Every value comes from the environment. This service holds NO user table:
identity, RBAC and directory data all come from Fusion_System_Administrator
over HTTP — see fusion_auth/.
"""
import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent.parent


def _load_env_file(path):
    """Fill in from .env whatever the environment has not already set.

    Local development only in practice: production passes real variables
    through systemd, and setdefault means those always win. Without this,
    `cp .env.example .env` does nothing and every entry point depends on one
    shell's exports.
    """
    try:
        lines = path.read_text().splitlines()
    except OSError:
        return
    for line in lines:
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        name, _, value = line.partition("=")
        os.environ.setdefault(name.strip(), value.strip().strip('"').strip("'"))


_load_env_file(BASE_DIR / ".env")


def env(name, default=None):
    v = os.environ.get(name)
    return default if v is None or v.strip() == "" else v.strip()


def env_bool(name, default=False):
    raw = env(name)
    return default if raw is None else raw.lower() in ("1", "true", "yes", "on")


def env_int(name, default=None):
    raw = env(name)
    try:
        return int(raw) if raw is not None else default
    except ValueError:
        return default


def env_list(name, default=None):
    raw = env(name)
    if raw is None:
        return list(default or [])
    return [x.strip() for x in raw.split(",") if x.strip()]


SECRET_KEY = env("DJANGO_SECRET_KEY", "django-insecure-dev-only-change-me")
DEBUG = False
ALLOWED_HOSTS = env_list("DJANGO_ALLOWED_HOSTS", ["localhost", "127.0.0.1"])

# django.contrib.auth is here because DRF needs it; fusion_auth authenticates.
DJANGO_APPS = [
    "django.contrib.contenttypes",
    "django.contrib.auth",
    "django.contrib.staticfiles",
]

THIRD_PARTY_APPS = [
    "rest_framework",
    "corsheaders",
    "django_filters",
    "drf_spectacular",
]

# No models. Installed so its AppConfig runs and registers the session checks.
LOCAL_APPS = [
    "fusion_auth",
]

# Each module is an independent Django app: own tables, migrations and contract.
PLATFORM_MODULES = [
    "modules.directory",         # who people are, projected from IAM
    "modules.accesscontrol",     # which modules a role may enter
]

# See docs/03-platform/module-authoring-guide.md to add one.
DOMAIN_MODULES = [
    "modules.placement",
    "modules.elm",
]

INSTALLED_APPS = (DJANGO_APPS + THIRD_PARTY_APPS + LOCAL_APPS
                  + PLATFORM_MODULES + DOMAIN_MODULES)

MIDDLEWARE = [
    "corsheaders.middleware.CorsMiddleware",
    "django.middleware.security.SecurityMiddleware",
    "core.observability.middleware.RequestIDMiddleware",
    "django.middleware.common.CommonMiddleware",
    # X_FRAME_OPTIONS is inert without this; only this middleware emits it.
    "django.middleware.clickjacking.XFrameOptionsMiddleware",
]

# No CsrfViewMiddleware: core/api/csrf.py does it from the authentication classes.

ROOT_URLCONF = "config.urls"
WSGI_APPLICATION = "config.wsgi.application"

TEMPLATES = [
    {
        "BACKEND": "django.template.backends.django.DjangoTemplates",
        "DIRS": [],
        "APP_DIRS": True,
        "OPTIONS": {"context_processors": []},
    }
]

# One database, owned by this service; person data comes from modules.directory.
DATABASES = {
    "default": {
        "ENGINE": "django.db.backends.postgresql",
        "NAME": env("DB_NAME", "fusion_integrated"),
        "USER": env("DB_USER", "fusion_admin"),
        "PASSWORD": env("DB_PASSWORD", ""),
        "HOST": env("DB_HOST", "127.0.0.1"),
        "PORT": env("DB_PORT", "5432"),
        # MUST stay 0 under PgBouncer transaction pooling, which leaks session state.
        "CONN_MAX_AGE": env_int("DB_CONN_MAX_AGE", 0),
    }
}
DEFAULT_AUTO_FIELD = "django.db.models.BigAutoField"

#: How long a cached directory row may be trusted before it is refetched.
DIRECTORY_MAX_AGE_SECONDS = env_int("DIRECTORY_MAX_AGE_SECONDS", 6 * 60 * 60)

# The IAM. This service is a client of it and caches nothing it cannot rebuild.
IAM_BASE_URL = env("IAM_BASE_URL", "http://127.0.0.1:8001")
IAM_API_PREFIX = env("IAM_API_PREFIX", "/api")
IAM_SERVICE_TOKEN = env("IAM_SERVICE_TOKEN", "")
IAM_TIMEOUT_SECONDS = env_int("IAM_TIMEOUT_SECONDS", 5)
IAM_SESSION_CACHE_SECONDS = env_int("IAM_SESSION_CACHE_SECONDS", 60)
IAM_AUTH_COOKIE_NAME = env("IAM_AUTH_COOKIE_NAME", "fusion_session")

CACHES = {
    "default": (
        {
            "BACKEND": "django.core.cache.backends.redis.RedisCache",
            "LOCATION": env("REDIS_CACHE_URL"),
        }
        if env("REDIS_CACHE_URL")
        else {
            "BACKEND": "django.core.cache.backends.locmem.LocMemCache",
            "LOCATION": "fusion-integrated",
        }
    )
}

CELERY_BROKER_URL = env("REDIS_BROKER_URL", "memory://")
CELERY_TASK_ALWAYS_EAGER = env_bool("CELERY_TASK_ALWAYS_EAGER", False)
CELERY_TASK_ACKS_LATE = True
CELERY_TASK_REJECT_ON_WORKER_LOST = True

# Console by default, so a laptop never mails 3,000 students by accident.
EMAIL_BACKEND = env("DJANGO_EMAIL_BACKEND",
                    "django.core.mail.backends.console.EmailBackend")
EMAIL_HOST = env("EMAIL_HOST", "localhost")
EMAIL_PORT = env_int("EMAIL_PORT", 25)
EMAIL_HOST_USER = env("EMAIL_HOST_USER", "")
EMAIL_HOST_PASSWORD = env("EMAIL_HOST_PASSWORD", "")
EMAIL_USE_TLS = env_bool("EMAIL_USE_TLS", False)
DEFAULT_FROM_EMAIL = env("DEFAULT_FROM_EMAIL",
                         "Placement Cell <placement@iiitdmj.ac.in>")

#: Ceiling per worker pass, so a runaway loop cannot mail the institute.
NOTIFY_MAX_PER_RUN = env_int("NOTIFY_MAX_PER_RUN", 500)
#: Attempts before a notification is parked as failed for a human to look at.
NOTIFY_MAX_ATTEMPTS = env_int("NOTIFY_MAX_ATTEMPTS", 5)
#: A dozen events a day is legitimate during a drive; thirty is a bug.
NOTIFY_DAILY_CAP_PER_RECIPIENT = env_int("NOTIFY_DAILY_CAP_PER_RECIPIENT", 20)

#: Pre-Drive uploads, still served but never written; outside BASE_DIR or boot fails.
PLACEMENT_UPLOAD_ROOT = env(
    "PLACEMENT_UPLOAD_ROOT",
    str(Path.home() / ".local" / "share" / "fusion-integrated" / "uploads"))
#: When set, legacy reads go to nginx via X-Accel-Redirect. Must be `internal;`.
PLACEMENT_UPLOAD_INTERNAL_PREFIX = env("PLACEMENT_UPLOAD_INTERNAL_PREFIX", "")

# No multipart endpoints remain, so this only caps the JSON body.
DATA_UPLOAD_MAX_MEMORY_SIZE = 1024 * 1024

REST_FRAMEWORK = {
    "DEFAULT_AUTHENTICATION_CLASSES": [
        "fusion_auth.authentication.IamSessionAuthentication",
    ],
    "DEFAULT_PERMISSION_CLASSES": [
        "fusion_auth.permissions.IsAuthenticatedPrincipal",
    ],
    "DEFAULT_PAGINATION_CLASS": "core.api.pagination.CursorPagination",
    "PAGE_SIZE": 25,
    "DEFAULT_FILTER_BACKENDS": ["django_filters.rest_framework.DjangoFilterBackend"],
    "EXCEPTION_HANDLER": "core.api.exceptions.exception_handler",
    "DEFAULT_SCHEMA_CLASS": "drf_spectacular.openapi.AutoSchema",
    "UNAUTHENTICATED_USER": None,
    # Unset, DRF throttles on the whole client-controlled X-Forwarded-For.
    "NUM_PROXIES": env_int("DJANGO_NUM_PROXIES", 1),
    # Not DRF's ScopedRateThrottle: it keys on request.user.pk, absent here.
    "DEFAULT_THROTTLE_CLASSES": ["core.api.throttling.PrincipalScopedThrottle"],
    # Only endpoints opting in via `throttle_scope` are limited.
    "DEFAULT_THROTTLE_RATES": {
        "recruiter_login": "5/min",
        "recruiter_invite_accept": "10/hour",
        "apply": "30/hour",
        "export": "5/hour",
        "upload": "20/hour",
        "directory_search": "120/hour",
    },
}

# Recruiter passwords only; PBKDF2 verifies an older hash, then upgrades it.
PASSWORD_HASHERS = [
    "django.contrib.auth.hashers.Argon2PasswordHasher",
    "django.contrib.auth.hashers.PBKDF2PasswordHasher",
]

SPECTACULAR_SETTINGS = {
    "TITLE": "Fusion-Integrated API",
    "DESCRIPTION": "Non-academic platform. Independent modules, one login.",
    "VERSION": "1.0.0",
    "SERVE_INCLUDE_SCHEMA": False,
}

CORS_ALLOW_ALL_ORIGINS = False
CORS_ALLOWED_ORIGINS = env_list("DJANGO_CORS_ALLOWED_ORIGINS", ["http://localhost:5173"])
CORS_ALLOW_CREDENTIALS = True

LANGUAGE_CODE = "en-us"
TIME_ZONE = "Asia/Kolkata"
# After TIME_ZONE, which it reads, or a crontab entry fires at the wrong hour.
CELERY_TIMEZONE = TIME_ZONE
CELERY_ENABLE_UTC = True
USE_I18N = True
USE_TZ = True
STATIC_URL = "/static/"
STATIC_ROOT = BASE_DIR / "staticfiles"

SECURE_CONTENT_TYPE_NOSNIFF = True
SECURE_REFERRER_POLICY = "strict-origin-when-cross-origin"
# SAMEORIGIN, not DENY: Fusion-client embeds these screens, same origin in prod.
X_FRAME_OPTIONS = "SAMEORIGIN"

# W003: CSRF is enforced by core/api/csrf.py. See the note above MIDDLEWARE.
# W019: the portal frames these screens deliberately, and only same origin.
SILENCED_SYSTEM_CHECKS = ["security.W003", "security.W019"]

# Without this, nothing is configured and every INFO audit line is discarded.
LOGGING = {
    "version": 1,
    "disable_existing_loggers": False,
    "formatters": {
        "plain": {
            "format": "%(asctime)s %(levelname)s %(name)s %(message)s",
            "datefmt": "%Y-%m-%d %H:%M:%S",
        },
    },
    "handlers": {
        "console": {"class": "logging.StreamHandler", "formatter": "plain"},
    },
    "root": {"handlers": ["console"], "level": "WARNING"},
    "loggers": {
        # Raise the level to quiet a host down; do not remove the handler.
        "fusion": {"level": env("FUSION_LOG_LEVEL", "INFO"), "propagate": True},
    },
}
```


# 2026-10-12T00:11:51 (model=qwen2.5-coder:7b num_ctx=12288 prompt_tokens=2100 output_tokens=1338 wall=287s)

Prompt file: .\logs\prompts\05_api.txt
Context: modules/elm/models.py, modules/elm/services/leave.py, modules/directory/api/views.py, modules/directory/api/urls.py

## Prompt

Create files under modules/elm/api/ following modules/directory/api patterns (APIView, permission_classes=[HasPermission("...")] from fusion_auth.permissions, extend_schema from drf_spectacular). request.user is Principal with .user_id. Views must call modules/elm/services/leave.py for writes; do not mutate rows directly in views. Do not catch core.api.exceptions.
- __init__.py empty.
- serializers.py: LeaveTypeSerializer fields id, code, name, max_days_per_year, requires_document, is_active. LeaveBalanceSerializer fields id, leave_type, year, allotted, used, plus available SerializerMethodField = allotted-used. LeaveApplicationSerializer fields id, employee_id, leave_type, start_date, end_date, days, reason, status, approver_id, remarks, decided_at, created_at; all read-only. ApplyInputSerializer: leave_type IntegerField, start_date/end_date DateField, reason CharField max_length=2000. DecisionInputSerializer: approve BooleanField, remarks optional blank max_length=2000.
- views.py: LeaveTypeListView GET permission leave_elm.application.view, active types ordered by name. MyApplicationsView GET own applications newest first; POST permission leave_elm.application.apply, validate input, call services.leave.apply, return 201 serialized. Use get_permissions() to choose HasPermission by request method. PendingApprovalsView GET permission leave_elm.application.approve, all SUBMITTED except caller's own, oldest first. DecideView POST <int:pk> permission approve, validate input, call services.leave.decide. WithdrawView POST <int:pk> permission apply, call withdraw. CancelView POST <int:pk> permission apply, call cancel_approved. MyBalanceView GET permission leave_elm.balance.view, caller balances for ?year= (default current year using timezone.localdate().year); nonnumeric year raises BadRequestError("year must be a number.", code="invalid_filter"). Every write view returns LeaveApplicationSerializer data.
- urls.py: paths types, applications, applications/pending, applications/<int:pk>/decide, applications/<int:pk>/withdraw, applications/<int:pk>/cancel, balance. Each URL name starts elm-.
Output complete files only.


## Model response

FILE: modules/elm/api/__init__.py
```
```

FILE: modules/elm/api/serializers.py
```python
from rest_framework import serializers
from modules.elm.models import LeaveType, LeaveBalance, LeaveApplication


class LeaveTypeSerializer(serializers.ModelSerializer):
    class Meta:
        model = LeaveType
        fields = ["id", "code", "name", "max_days_per_year", "requires_document", "is_active"]


class LeaveBalanceSerializer(serializers.ModelSerializer):
    available = serializers.SerializerMethodField()

    class Meta:
        model = LeaveBalance
        fields = ["id", "leave_type", "year", "allotted", "used", "available"]

    def get_available(self, obj):
        return obj.allotted - obj.used


class LeaveApplicationSerializer(serializers.ModelSerializer):
    class Meta:
        model = LeaveApplication
        fields = [
            "id",
            "employee_id",
            "leave_type",
            "start_date",
            "end_date",
            "days",
            "reason",
            "status",
            "approver_id",
            "remarks",
            "decided_at",
            "created_at",
        ]
        read_only_fields = fields


class ApplyInputSerializer(serializers.Serializer):
    leave_type = serializers.IntegerField()
    start_date = serializers.DateField()
    end_date = serializers.DateField()
    reason = serializers.CharField(max_length=2000)


class DecisionInputSerializer(serializers.Serializer):
    approve = serializers.BooleanField()
    remarks = serializers.CharField(max_length=2000, required=False, blank=True)
```

FILE: modules/elm/api/views.py
```python
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework.permissions import IsAuthenticated
from drf_spectacular.utils import extend_schema
from fusion_auth.permissions import HasPermission
from modules.elm import services
from modules.elm.api.serializers import (
    LeaveTypeSerializer,
    LeaveApplicationSerializer,
    ApplyInputSerializer,
    DecisionInputSerializer,
)


class LeaveTypeListView(APIView):
    permission_classes = [IsAuthenticated, HasPermission("leave_elm.application.view")]

    @extend_schema(responses=LeaveTypeSerializer(many=True))
    def get(self, request):
        types = LeaveType.objects.filter(is_active=True).order_by("name")
        serializer = LeaveTypeSerializer(types, many=True)
        return Response(serializer.data)


class MyApplicationsView(APIView):
    permission_classes = [IsAuthenticated]

    @extend_schema(responses=LeaveApplicationSerializer(many=True))
    def get(self, request):
        applications = LeaveApplication.objects.filter(employee_id=request.user.user_id).order_by("-created_at")
        serializer = LeaveApplicationSerializer(applications, many=True)
        return Response(serializer.data)

    @extend_schema(request=ApplyInputSerializer, responses=LeaveApplicationSerializer)
    def post(self, request):
        serializer = ApplyInputSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        application = services.apply(request.user, serializer.validated_data["leave_type"], serializer.validated_data["start_date"], serializer.validated_data["end_date"], serializer.validated_data["reason"])
        return Response(LeaveApplicationSerializer(application).data, status=201)


class PendingApprovalsView(APIView):
    permission_classes = [IsAuthenticated, HasPermission("leave_elm.application.approve")]

    @extend_schema(responses=LeaveApplicationSerializer(many=True))
    def get(self, request):
        applications = LeaveApplication.objects.filter(status="SUBMITTED").exclude(employee_id=request.user.user_id).order_by("created_at")
        serializer = LeaveApplicationSerializer(applications, many=True)
        return Response(serializer.data)


class DecideView(APIView):
    permission_classes = [IsAuthenticated, HasPermission("leave_elm.application.approve")]

    @extend_schema(request=DecisionInputSerializer, responses=LeaveApplicationSerializer)
    def post(self, request, pk):
        serializer = DecisionInputSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        application = services.decide(request.user, pk, serializer.validated_data["approve"], serializer.validated_data.get("remarks", ""))
        return Response(LeaveApplicationSerializer(application).data)


class WithdrawView(APIView):
    permission_classes = [IsAuthenticated, HasPermission("leave_elm.application.apply")]

    @extend_schema(responses=LeaveApplicationSerializer)
    def post(self, request, pk):
        application = services.withdraw(request.user, pk)
        return Response(LeaveApplicationSerializer(application).data)


class CancelView(APIView):
    permission_classes = [IsAuthenticated, HasPermission("leave_elm.application.apply")]

    @extend_schema(responses=LeaveApplicationSerializer)
    def post(self, request, pk):
        application = services.cancel_approved(request.user, pk)
        return Response(LeaveApplicationSerializer(application).data)


class MyBalanceView(APIView):
    permission_classes = [IsAuthenticated, HasPermission("leave_elm.balance.view")]

    @extend_schema(responses=LeaveBalanceSerializer(many=True))
    def get(self, request):
        year = request.query_params.get("year")
        if year is None:
            year = timezone.localtime().year
        try:
            year = int(year)
        except (TypeError, ValueError):
            raise BadRequestError("year must be a number.", code="invalid_filter")
        balances = LeaveBalance.objects.filter(employee_id=request.user.user_id, year=year)
        serializer = LeaveBalanceSerializer(balances, many=True)
        return Response(serializer.data)
```

FILE: modules/elm/api/urls.py
```python
from django.urls import path

from modules.elm.api.views import (
    LeaveTypeListView,
    MyApplicationsView,
    PendingApprovalsView,
    DecideView,
    WithdrawView,
    CancelView,
    MyBalanceView,
)

urlpatterns = [
    path("types", LeaveTypeListView.as_view(), name="elm-types"),
    path("applications", MyApplicationsView.as_view(), name="elm-applications"),
    path("applications/pending", PendingApprovalsView.as_view(), name="elm-applications-pending"),
    path("applications/<int:pk>/decide", DecideView.as_view(), name="elm-applications-decide"),
    path("applications/<int:pk>/withdraw", WithdrawView.as_view(), name="elm-applications-withdraw"),
    path("applications/<int:pk>/cancel", CancelView.as_view(), name="elm-applications-cancel"),
    path("balance", MyBalanceView.as_view(), name="elm-balance"),
]
```


Manual correction: Removed stray Markdown code fence from modules/elm/api/__init__.py; the file is intentionally empty.

Manual correction: Changed DRF serializer argument blank=True to allow_blank=True in DecisionInputSerializer for framework compatibility.

Manual correction: Added missing LeaveBalanceSerializer import in modules/elm/api/views.py to match the generated API view's expected interface.
